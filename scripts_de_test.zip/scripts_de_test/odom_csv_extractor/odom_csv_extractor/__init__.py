# odom_csv_extractor/odom_csv_extractor/__init__.py

__version__ = '0.0.0'

from .extract_to_csv import main

__all__ = ['main']